﻿using APIRamoSaude.Controllers;
using APIRamoSaude.Interfaces;
using APIRamoSaude.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace APIRamoSaudeTests
{
    public class ConsultasControllerTests
    {
        // Preparação
        // Mock: Valida a classe sem interferir no banco de dados
        private readonly Mock<IConsultaRepository> _mockRepo;
        private readonly ConsultasController _controller;

        // Preparação
        // Método construtor
        public ConsultasControllerTests()
        {
            _mockRepo = new Mock<IConsultaRepository>();
            _controller = new ConsultasController(_mockRepo.Object);
        }

        [Fact]
        public void QuandoChamadoRetornaOk()
        {

            // Execução
            var result = _controller.Listar();
            // Retorno
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public void TestGetAllUsuario()
        {
            // Execução 
            var actionResult = _controller.Listar();
            var okObjectResult = actionResult as OkObjectResult;
            okObjectResult.Value = new List<Consulta>();
            // Retorno
            Assert.IsAssignableFrom<List<Consulta>>(okObjectResult.Value);

        }

        [Fact]
        public void DeveRetornarCodeSuccess()
        {
            // Execução 
            var actionResult = _controller.Listar();
            var result = actionResult as OkObjectResult;
            // Retorno esperado
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public void DeveRetornarNotNull()
        {
            // Execução 
            var actionResult = _controller.Listar();
            // Retorno esperado
            Assert.NotNull(actionResult);
        }
    }
}
