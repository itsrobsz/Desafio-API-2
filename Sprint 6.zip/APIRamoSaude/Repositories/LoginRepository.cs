﻿using APIRamoSaude.Contexts;
using APIRamoSaude.Interfaces;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace APIRamoSaude.Repositories
{
    public class LoginRepository : ILoginRepository
    {
        private readonly CodeFirstContext ctx;
        public LoginRepository(CodeFirstContext _ctx)
        {
            ctx = _ctx;
        }

        public string Logar(string email, string senha)
        {
            //return ctx.Usuarios.Where(x => x.Email == email && x.Senha == senha).FirstOrDefault();

            // Verifica se existe um usuário com o email informado 
            var usuario = ctx.Usuario.FirstOrDefault(x => x.Email == email);

            if (usuario != null)
            {
                // Verifica se a senha dada como argumento é igual a do banco daquele usuário
                bool confere = BCrypt.Net.BCrypt.Verify(senha, usuario.Senha);

                if (confere)
                {
                    // Cria as credenciais do JWT
                    // Definição de Claims (credencias/registro JWT)
                    var minhasClaims = new[]
                    {
                        new Claim(JwtRegisteredClaimNames.Email, usuario.Email),
                        new Claim(JwtRegisteredClaimNames.Jti, usuario.Id.ToString()),
                        new Claim(ClaimTypes.Role, usuario.IdTipoUsuario.ToString()),
                        new Claim("Tipo de Usuário", $"{usuario.IdTipoUsuario}")

                    };

                    // Criação de chaves
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("ramoSaude-chave-autenticacao"));

                    // Criação de credenciais
                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    // Gerar o Token
                    var meuToken = new JwtSecurityToken(
                        issuer: "ramoSaude.WebAPI",
                        audience: "ramoSaude.WebAPI",
                        claims: minhasClaims,
                        expires: DateTime.Now.AddMinutes(30),
                        signingCredentials: creds
                        );

                    return new JwtSecurityTokenHandler().WriteToken(meuToken);
                }

            }

            return null;
        }
    }
}
