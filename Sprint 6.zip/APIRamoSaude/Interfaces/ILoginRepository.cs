﻿namespace APIRamoSaude.Interfaces
{
    public interface ILoginRepository
    {
        string Logar(string email, string senha); 
    }
}
