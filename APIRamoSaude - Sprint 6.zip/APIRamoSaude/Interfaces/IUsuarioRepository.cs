﻿using APIRamoSaude.Models;
using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;

namespace APIRamoSaude.Interfaces
{
    public interface IUsuarioRepository
    {
        //CRUD
        Usuario Inserir(Usuario usuario);
        ICollection<Usuario> ListarTodos();
        Usuario BuscarPorId(int id);
        void Alterar(Usuario Usuario);
        void Excluir(Usuario Usuario);
        void AlterarParcialmente(JsonPatchDocument patchUsuario, Usuario usuario);
    }

}
