﻿using APIRamoSaude.Controllers;
using APIRamoSaude.Interfaces;
using APIRamoSaude.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace APIRamoSaudeTests
{
    public class PacientesControllerTests
    {
        // Instância dos objetos
        // Mock: Valida a classe sem interferir no banco de dados
        private readonly Mock<IPacienteRepository> _mockRepo;
        private readonly PacientesController _controller;

        // Preparação
        // Método construtor
        public PacientesControllerTests()
        {
            _mockRepo = new Mock<IPacienteRepository>();
            _controller = new PacientesController(_mockRepo.Object);
        }

        [Fact]
        public void QuandoChamadoRetornaOk()
        {
            // Execução
            var result = _controller.Listar();
            // Retorno esperado
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public void TestGetAllUsuario()
        {
            // Execução 
            var actionResult = _controller.Listar();
            var okObjectResult = actionResult as OkObjectResult;
            okObjectResult.Value = new List<Paciente>();
            // Retorno esperado
            Assert.IsAssignableFrom<List<Paciente>>(okObjectResult.Value);

        }

        [Fact]
        public void DeveRetornarCodeSuccess()
        {
            // Execução 
            var actionResult = _controller.Listar();
            var result = actionResult as OkObjectResult;
            // Retorno esperado
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public void DeveRetornarNotNull()
        {
            // Execução 
            var actionResult = _controller.Listar();
            // Retorno esperado
            Assert.NotNull(actionResult);
        }
    }
}
