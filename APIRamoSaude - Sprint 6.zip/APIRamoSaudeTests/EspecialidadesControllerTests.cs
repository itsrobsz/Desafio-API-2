﻿using APIRamoSaude.Controllers;
using APIRamoSaude.Interfaces;
using APIRamoSaude.Models;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace APIRamoSaudeTests
{
    public class EspecialidadesControllerTests
    {
        // Instância dos objetos
        // Mock: Valida a classe sem interferir no banco de dados
        private readonly Mock<IEspecialidadeRepository> _mockRepo;
        private readonly EspecialidadesController _controller;

        // Preparação
        // Método construtor
        public EspecialidadesControllerTests()
        {
            _mockRepo = new Mock<IEspecialidadeRepository>();
            _controller = new EspecialidadesController(_mockRepo.Object);
        }

        [Fact]
        public void QuandoChamadoRetornaOk()
        {
            // Execução
            var result = _controller.Listar();
            // Retorno esperado
            Assert.IsType<OkObjectResult>(result);
        }

        [Fact]
        public void TestGetAllUsuario()
        {
            // Execução 
            var actionResult = _controller.Listar();
            var okObjectResult = actionResult as OkObjectResult;
            okObjectResult.Value = new List<Especialidade>();
            // Retorno esperado
            Assert.IsAssignableFrom<List<Especialidade>>(okObjectResult.Value);

        }

        [Fact]
        public void DeveRetornarCodeSuccess()
        {
            // Execução 
            var actionResult = _controller.Listar();
            var result = actionResult as OkObjectResult;
            // Retorno esperado
            Assert.Equal(200, result.StatusCode);
        }

        [Fact]
        public void DeveRetornarNotNull()
        {
            // Execução 
            var actionResult = _controller.Listar();
            // Retorno esperado
            Assert.NotNull(actionResult);
        }
    }
}
